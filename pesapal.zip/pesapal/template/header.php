<div class="container-fluid header">
<div id="nav">
<nav class="navbar navbar-inverse" role="navigation">
<div class="navbar-header">
<label><a href="home.php">LATCH TECH</a></label>
<button type="button" id="nav-toggle" class="navbar-toggle" data-toggle="collapse" data-target="#main-nav"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
</div>
<div id="main-nav" class="collapse navbar-collapse navStyle">
<ul>
	<li><a href="home.php">HOME</a></li> 
	<li><a href="settings.php">SETTINGS</a></li>  
	<li><a href="items.php">MANAGE ITEMS</a></li>   
	<li><a href="users.php">MANAGE USERS</a></li>   
	<li><a href="orders.php">MANAGE ORDERS</a></li>   
	<li><a href="payments.php">MANAGE PAYMENTS</a></li> 
	<li><a href="messages.php">MANAGE SMS</a></li> 
</ul>
</div>
</nav>
</div>
</div>