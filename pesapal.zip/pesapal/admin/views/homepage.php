<?php include '../template/adminheader.php'; ?>

<link rel="stylesheet" href="../../css/bootstrap.css">
<link rel="stylesheet" href="../../css/style.css">

<h3>HOME</h3>
	<table>
		<tr>
			<td>
				<div style="background:blue">
					SETTINGS
				</div>
				<div>
					<ul>
						<li>Can Edit</li>
						<li>Can Update</li>
						<li>Can Delete</li>
						<li></li>
					</ul>
				</div>
			</td>
			<td>
				<div style="background:blue">
					MANAGE USERS
				</div>
				<div>
					<ul>
						<li>Can Create</li>
						<li>Can Edit</li>
						<li>Can Update</li>
						<li>Can Delete</li>
					</ul>
				</div>
			</td>
		</tr>
		<tr>
			<td>
				<div style="background:blue">
					MANAGE ORDERS
				</div>
				<div>
					<ul>
						<li>Can Create</li>
						<li>Can Edit</li>
						<li>Can Update</li>
						<li>Can Delete</li>
					</ul>
				</div>
			</td>
			<td>
				<div style="background:blue">
					MANAGE PAYMENTS
				</div>
				<div>
					<ul>
						<li>Can Create</li>
						<li>Can Edit</li>
						<li>Can Update</li>
						<li>Can Delete</li>
					</ul>
				</div>
			</td>
		</tr>
	</table>

<?php include '../template/adminfooter.php'; ?>