<div class="container-fluid header">
<div id="nav">
<nav class="navbar navbar-inverse" role="navigation">
<div class="navbar-header">
<label><a href="home.php">LATCH STORES</a></label>
<button type="button" id="nav-toggle" class="navbar-toggle" data-toggle="collapse" data-target="#main-nav"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
</div>
<div id="main-nav" class="collapse navbar-collapse navStyle">
<ul>
	<li><a href="homepage.php">HOME</a></li> 
	<li><a href="managesettings.php">MANAGE SETTINGS</a></li>  
	<li><a href="manageitems.php">MANAGE ITEMS</a></li>  
	<li><a href="manageorders.php">MANAGE ORDERS</a></li>   
	<li><a href="managepayments.php">MANAGE PAYMENTS</a></li> 
	<li><a href="managemessages.php">MANAGE MESSAGES</a></li>   
	<li><a href="manageusers.php">MANAGE USERS</a></li>  
</ul>
</div>
</nav>
</div>
</div>