<div class="container-fluid footer">
<p>&copy; 2015 - <script>var date = new Date(); var thisyear = date.getFullYear(); document.write(thisyear);</script> Latch Technologies Limited | Everything is bound to get better
<br>email: <a href="mailto:ewanguba@gmail.com">ewanguba@gmail.com</a></p>
</div>